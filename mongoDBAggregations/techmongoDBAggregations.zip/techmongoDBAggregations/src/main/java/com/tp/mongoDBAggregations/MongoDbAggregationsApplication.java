package com.tp.mongoDBAggregations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbAggregationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbAggregationsApplication.class, args);
	}

}
