package com.tp.mongoDBAggregations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbAggregationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
